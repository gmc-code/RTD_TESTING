

from .wordjumble import setup

