

from .wordordering import setup

